"use client";
import styled from "styled-components";

export const Container = styled.div`
  @import url("https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap");

  width: 90%;
  margin: 0 auto;
  background: #fff;
  text-align: center;
  border-radius: 5px;
  padding: 50px 35px 10px 35px;

  * {
    margin: 0;
    padding: 0;
    outline: none;
    font-family: "Poppins", sans-serif;
  }

  header {
    font-size: 35px;
    font-weight: 600;
    margin: 0 0 30px 0;
  }
  .form-outer {
    width: 100%;
    overflow: hidden;
  }
  .form-outer form {
    display: flex;
    width: 400%;
  }
  .form-outer form .page {
    width: 25%;
    transition: margin-left 0.3s ease-in-out;
  }
  .form-outer form .page .title {
    text-align: center;
    font-size: 25px;
    font-weight: 500;
  }
  .form-outer form .page .field {
    width: 100%;
    height: 45px;
    margin: 45px 0;
    display: flex;
    position: relative;
  }
  form .page .field .label {
    position: absolute;
    top: -30px;
    font-weight: 500;
  }
  form .page .field input {
    height: 100%;
    width: 100%;
    border: 1px solid lightgrey;
    border-radius: 5px;
    padding-left: 15px;
    font-size: 18px;
  }
  form .page .field select {
    width: 100%;
    padding-left: 10px;
    font-size: 17px;
    font-weight: 500;
  }
  form .page .field button {
    width: 100%;
    height: calc(100% + 5px);
    border: none;
    background: #d33f8d;
    margin-top: -20px;
    border-radius: 5px;
    color: #fff;
    cursor: pointer;
    font-size: 18px;
    font-weight: 500;
    letter-spacing: 1px;
    text-transform: uppercase;
    transition: 0.5s ease;
  }
  form .page .field button:hover {
    background: #000;
  }
  form .page .btns button {
    margin-top: -20px !important;
  }
  form .page .btns button.prev {
    margin-right: 3px;
    font-size: 17px;
  }
  form .page .btns button.next {
    margin-left: 3px;
  }
  .progress-bar {
    display: flex;
    margin: 40px 0;
    user-select: none;
    width: 330px;
    margin: 50px auto;
    
  }
  .progress-bar .step {
    text-align: center;
    width: 100%;
    position: relative;
  }
  .progress-bar .step p {
    font-weight: 500;
    font-size: 18px;
    color: #000;
    margin-bottom: 8px;
  }
  .progress-bar .step .bullet {
    height: 25px;
    width: 25px;
    border: 2px solid #000;
    display: inline-block;
    border-radius: 50%;
    position: relative;
    transition: 0.2s;
    font-weight: 500;
    font-size: 17px;
    line-height: 25px;
  }
  .progress-bar .step .bullet.active {
    border-color: #d43f8d;
    background: #d43f8d;
  }
  .progress-bar .step .bullet span {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
  }
  .progress-bar .step .bullet.active span {
    display: none;
  }
  .progress-bar .step .bullet:before,
  .progress-bar .step .bullet:after {
    position: absolute;
    content: "";
    bottom: 11px;
    right: -51px;
    height: 3px;
    width: 44px;
    background: #262626;
  }
  .progress-bar .step .bullet.active:after {
    background: #d43f8d;
    transform: scaleX(0);
    transform-origin: left;
    animation: animate 1s linear forwards;
  }
  @keyframes animate {
    100% {
      transform: scaleX(1);
    }
  }
  .progress-bar .step:last-child .bullet:before,
  .progress-bar .step:last-child .bullet:after {
    display: none;
  }
  .progress-bar .step p.active {
    color: #d43f8d;
    transition: 0.2s linear;
  }
  .progress-bar .step .check {
    position: absolute;
    left: 50%;
    top: 70%;
    font-size: 15px;
    transform: translate(-50%, -50%);
    display: none;
  }
  .progress-bar .step .check.active {
    display: block;
    color: #fff;
  }
`;
