import "./soon.css";
export default function BlogPage() {
  return (
    <div class="bgimg">
      <div class="topleft">Welcome</div>
      <div class="middle">
        <h1>COMING SOON</h1>
        <hr />
        <p>Blogs are under construction</p>
      </div>
      <div class="bottomleft">
        <p>Internet Madrasa</p>
      </div>
    </div>
  );
}
