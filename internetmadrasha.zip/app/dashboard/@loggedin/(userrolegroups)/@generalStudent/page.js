import React from 'react';

function page(props) {
    return (
        <h1 className='text-center mt-10'>Student role layout</h1>
    );
}

export default page;