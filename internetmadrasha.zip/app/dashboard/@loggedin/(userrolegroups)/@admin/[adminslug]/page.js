import DashboardMetrics from "@/customComponents/dashboardMetrics/DashboardMetrics";


function page(props) {
    return (
        <DashboardMetrics/>
    );
}

export default page;