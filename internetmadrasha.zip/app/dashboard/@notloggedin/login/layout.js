
function notLoggedInlayout({children}) {
    return (
        <>  
            {children}
        </>
    );

}

export default notLoggedInlayout;