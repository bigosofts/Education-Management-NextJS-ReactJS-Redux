import SignupCondition from "@/customComponents/SignupCondition/SignupCondition";


function page(props) {
  return (
    <>
      <SignupCondition />
      
    </>
  );
}

export default page;
