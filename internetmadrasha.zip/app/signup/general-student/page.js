function GeneralStudentPage() {
  return (
    <>
      <div>General Student Page</div>
    </>
  );
}

export default GeneralStudentPage;
