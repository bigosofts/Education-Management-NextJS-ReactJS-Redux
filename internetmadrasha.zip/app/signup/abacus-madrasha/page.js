import AbacusMadrashaSignupForm from "@/customComponents/allCustomComponents/abacusMadrashaSignup/abacusMadrashaSignupForm";

const Page = () => {
  return <AbacusMadrashaSignupForm />;
};

export default Page;
