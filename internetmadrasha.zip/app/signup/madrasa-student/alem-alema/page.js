import SignupStepAlemAlema from "@/customComponents/SignupStep/SignupStepAlemAlema";

function AlemAlemaPage() {
  return <SignupStepAlemAlema />;
}

export default AlemAlemaPage;
