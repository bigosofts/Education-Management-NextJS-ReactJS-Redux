import SignupConditionMadrasaStudent from "@/customComponents/SignupConditionMadrasaStudent/SignupConditionMadrasaStudent";

function MadrasaStudentPage() {
  return (
    <>
    
      <SignupConditionMadrasaStudent />
    </>
  );
}

export default MadrasaStudentPage;
