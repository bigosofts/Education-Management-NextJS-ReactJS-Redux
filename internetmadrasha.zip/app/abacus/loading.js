import Loader from "@/customComponents/loader/Loader";
function LoaderComponent() {
  return <Loader />;
}

export default LoaderComponent;
